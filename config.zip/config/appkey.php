<?php 

return [
	'vision_key' => 'AIzaSyB2hobqSdhdytm1YsinxAUB5WQzZwsSjs8',
]; 
